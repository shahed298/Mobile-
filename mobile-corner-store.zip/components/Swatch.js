// ছবির বদলে রঙিন টাইলে আইকন। পরে <Image> দিয়ে আসল ছবি বসাতে পারেন।
export default function Swatch({ icon, tint, big = false }) {
  return (
    <div className={big ? 'swatch big' : 'swatch'} style={{ background: tint }} aria-hidden="true">
      <span className="icon">{icon}</span>
    </div>
  );
}
