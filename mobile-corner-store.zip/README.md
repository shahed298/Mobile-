# মোবাইল কর্নার — Vercel-এ চালানোর স্টার্টার ই-কমার্স

Next.js 14 (App Router)। পণ্য, কার্ট (ব্রাউজারে সেভ হয়), অর্ডার ফর্ম আর `/api/order` আছে।

## নিজের কম্পিউটারে চালান
    npm install
    npm run dev      # http://localhost:3000

## Vercel-এ ডিপ্লয়
1. একটা GitHub রিপোজিটরিতে এই ফোল্ডারের ফাইলগুলো পুশ করুন
2. vercel.com → Add New → Project → রিপোজিটরি ইমপোর্ট → Deploy (কোনো সেটিং বদলাতে হবে না)

## বদলানোর জায়গা
- পণ্য ও দাম: `lib/products.js`
- রঙ ও ডিজাইন: `app/globals.css`
- অর্ডার সেভ করা (ডাটাবেস): `app/api/order/route.js` — এখন শুধু Vercel লগে যায়
- অনলাইন পেমেন্ট (bKash/SSLCommerz/Stripe): চেকআউটের পরে যোগ করতে হবে
